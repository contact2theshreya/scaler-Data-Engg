
import time
import json
import logging
import requests
from kafka import KafkaProducer
from kafka.errors import KafkaError

# --- Configuration ---
# Kafka settings
KAFKA_TOPIC = 'crypto'
# Assumes Kafka is running on localhost. Change if your setup is different.
KAFKA_BROKER = 'kafka:29092'

# Binance API settings
BINANCE_API_URL = 'https://api.binance.com/api/v3/ticker/price'
# List of cryptocurrencies to track against USDT. Add or remove symbols as needed.
CRYPTO_SYMBOLS = ['BTCUSDT', 'ETHUSDT', 'DOGEUSDT', 'ADAUSDT', 'XRPUSDT']

# Fetch interval
FETCH_INTERVAL = 5  # seconds

# --- Logging Setup ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Main Application ---

def create_kafka_producer():
    """Creates and returns a Kafka producer, retrying on failure."""
    producer = None
    while producer is None:
        try:
            producer = KafkaProducer(
                bootstrap_servers=[KAFKA_BROKER],
                value_serializer=lambda v: json.dumps(v).encode('utf-8'),
                retries=5,
                acks='all'
            )
            logging.info("Successfully connected to Kafka broker at %s", KAFKA_BROKER)
            return producer
        except Exception as e:
            logging.error("Failed to connect to Kafka broker: %s. Retrying in 5 seconds...", e)
            time.sleep(5)

def fetch_crypto_prices():
    """Fetches cryptocurrency prices from the Binance API for each configured symbol."""
    all_prices = []
    for symbol in CRYPTO_SYMBOLS:
        try:
            # Query one symbol at a time to avoid batch formatting issues
            response = requests.get(BINANCE_API_URL, params={'symbol': symbol})
            response.raise_for_status()  # Raise an exception for bad status codes (4xx or 5xx)
            all_prices.append(response.json())
        except requests.exceptions.RequestException as e:
            # Log error for the specific symbol and continue with the next one
            logging.error("Error fetching data for symbol %s from Binance API: %s", symbol, e)
            
    return all_prices if all_prices else None

def main():
    """Main function to fetch prices and send them to the Kafka topic."""
    producer = create_kafka_producer()

    logging.info("Starting price fetch loop for symbols: %s", ", ".join(CRYPTO_SYMBOLS))

    while True:
        prices = fetch_crypto_prices()
        if prices:
            logging.info("Fetched prices for %d symbols.", len(prices))
            for price_data in prices:
                try:
                    # The message key can be the symbol for better partitioning
                    key = price_data['symbol'].encode('utf-8')

                    # Send data to the Kafka topic
                    future = producer.send(KAFKA_TOPIC, value=price_data, key=key)

                    # Optional: Wait for the send to complete to ensure delivery
                    record_metadata = future.get(timeout=10)
                    logging.debug("Sent %s to topic '%s' partition %d", price_data['symbol'], record_metadata.topic, record_metadata.partition)

                except KafkaError as e:
                    logging.error("Error sending message to Kafka: %s", e)
                except Exception as e:
                    logging.error("An unexpected error occurred while sending a message: %s", e)

        # Wait for the next fetch interval
        time.sleep(FETCH_INTERVAL)

if __name__ == "__main__":
    main()
