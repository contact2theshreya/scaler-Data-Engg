
import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col, current_timestamp
from pyspark.sql.types import StructType, StructField, StringType, DoubleType
from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS

# --- Configuration ---

# Kafka Configuration
KAFKA_BROKER = "kafka:29092"
KAFKA_TOPIC = "crypto"

# InfluxDB Configuration - These match the docker-compose.yml settings
INFLUXDB_URL = "http://influxdb:8086"
INFLUXDB_TOKEN = "my-super-secret-token"
INFLUXDB_ORG = "binance"
INFLUXDB_BUCKET = "crypto"

# Spark Configuration
APP_NAME = "CryptoStreamConsumer"
CHECKPOINT_DIR = "/tmp/spark_checkpoints/crypto_stream"


def get_spark_session():
    """Creates and returns a Spark session with the necessary Kafka package."""
    return (
        SparkSession.builder.appName(APP_NAME)
        .getOrCreate()
    )

def write_to_influxdb(df, epoch_id):
    """
    Writes a micro-batch DataFrame to InfluxDB.
    This function is called by foreachBatch.
    """
    if df.count() == 0:
        return

    print(f"--- Writing batch {epoch_id} to InfluxDB ---")
    
    # Collect data to the driver. Be cautious with large batches.
    rows = df.collect()

    try:
        with InfluxDBClient(url=INFLUXDB_URL, token=INFLUXDB_TOKEN, org=INFLUXDB_ORG) as client:
            write_api = client.write_api(write_options=SYNCHRONOUS)
            
            points = []
            for row in rows:
                point = (
                    Point("crypto_price")
                    .tag("symbol", row.symbol)
                    .field("price", row.price)
                    .time(row.processing_time)
                )
                points.append(point)
            
            write_api.write(bucket=INFLUXDB_BUCKET, org=INFLUXDB_ORG, record=points)
            print(f"Successfully wrote {len(rows)} points to InfluxDB bucket '{INFLUXDB_BUCKET}'.")

    except Exception as e:
        print(f"Error writing to InfluxDB: {e}")


def main():
    """Main function to set up and run the Spark Structured Streaming job."""
    spark = get_spark_session()
    spark.sparkContext.setLogLevel("WARN") # Reduce verbosity

    # Define the schema for the incoming JSON data from Kafka
    schema = StructType([
        StructField("symbol", StringType(), True),
        StructField("price", StringType(), True) # Read price as string initially
    ])

    # Read from Kafka source
    kafka_df = (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", KAFKA_BROKER)
        .option("subscribe", KAFKA_TOPIC)
        .option("startingOffsets", "latest") # Process new messages # offset
        .load()
    )

    # Transform the data
    transformed_df = (
        kafka_df.select(col("value").cast("string"))
        .select(from_json(col("value"), schema).alias("data"))
        .select("data.*")
        .withColumn("price", col("price").cast(DoubleType())) # Cast price to Double
        .withColumn("processing_time", current_timestamp()) # Add processing timestamp
    )

    # Write the stream to InfluxDB using foreachBatch
    query = (
        transformed_df.writeStream.outputMode("update")
        .foreachBatch(write_to_influxdb)
        .trigger(processingTime="10 seconds") # Trigger every 10 seconds
        .option("checkpointLocation", CHECKPOINT_DIR)
        .start()
    )

    print(f"Streaming query started. Writing to InfluxDB bucket '{INFLUXDB_BUCKET}'.")
    print("Waiting for termination...")
    query.awaitTermination()


if __name__ == "__main__":
    main()
