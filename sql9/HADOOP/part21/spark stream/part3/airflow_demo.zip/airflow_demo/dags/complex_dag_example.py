
from __future__ import annotations

import pendulum

from airflow.models.dag import DAG
from airflow.operators.bash import BashOperator

with DAG(
    dag_id="complex_dag_example",
    start_date=pendulum.datetime(2023, 1, 1, tz="UTC"),
    catchup=False,
    schedule=None,
    tags=["example"],
) as dag:
    # Create 25 tasks
    tasks = {
        i: BashOperator(task_id=f"job_{i}", bash_command=f"echo 'job {i}'")
        for i in range(1, 26)
    }

    # --- Define Complex Dependencies ---

    # Level 1: Initial parallel tasks
    start_tasks = [tasks[1], tasks[2], tasks[3]]

    # Level 2: Branching from initial tasks
    tasks[1] >> tasks[4]
    tasks[1] >> tasks[5]
    tasks[2] >> tasks[6]
    tasks[3] >> tasks[7]

    # Level 3: First merge point
    [tasks[4], tasks[5], tasks[6], tasks[7]] >> tasks[8]

    # Level 4: A small chain
    tasks[8] >> tasks[9] >> tasks[10]

    # Level 5: Major fan-out from the chain
    tasks[10] >> tasks[11]
    tasks[10] >> tasks[12]
    tasks[10] >> tasks[13]
    tasks[10] >> tasks[14]

    # Level 6: Parallel processing
    tasks[11] >> tasks[15]
    tasks[12] >> tasks[16]
    tasks[13] >> tasks[17]
    tasks[14] >> tasks[18]

    # Level 7: Intermediate merge points
    [tasks[15], tasks[16]] >> tasks[19]
    [tasks[17], tasks[18]] >> tasks[20]

    # Level 8: Another small chain
    tasks[19] >> tasks[21]
    tasks[20] >> tasks[22]

    # Level 9: Final branching
    tasks[21] >> tasks[23]
    tasks[22] >> tasks[24]

    # Level 10: Final sink/end point
    [tasks[23], tasks[24]] >> tasks[25]
