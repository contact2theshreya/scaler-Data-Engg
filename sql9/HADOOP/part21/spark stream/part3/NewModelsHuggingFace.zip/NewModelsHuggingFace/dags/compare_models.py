from pyspark.sql import SparkSession
from pyspark.sql.utils import AnalysisException
from datetime import date, timedelta
import os
import sys

def compare_daily_model_snapshots():
    """
    A Spark batch job to compare the current day's model list with the previous day's
    and identify new models.
    """
    spark = SparkSession.builder.appName("HuggingFaceModelComparison").master("local[*]").getOrCreate()

    print("Spark session created.")

    # CORRECTED PATH: This path corresponds to the mounted volume in docker-compose.yaml
    input_dir = "/opt/airflow/output"

    today = date.today()
    yesterday = today - timedelta(days=1)
    
    today_filename = f"{today.strftime('%Y%m%d')}.csv"
    yesterday_filename = f"{yesterday.strftime('%Y%m%d')}.csv"

    today_filepath = os.path.join(input_dir, today_filename)
    yesterday_filepath = os.path.join(input_dir, yesterday_filename)

    print(f"Today's file: {today_filepath}")
    print(f"Yesterday's file: {yesterday_filepath}")

    try:
        today_df = spark.read.csv(today_filepath, header=True, inferSchema=True)
        today_df = today_df.withColumnRenamed("Model ID", "model_id")

        try:
            yesterday_df = spark.read.csv(yesterday_filepath, header=True, inferSchema=True)
            yesterday_df = yesterday_df.withColumnRenamed("Model ID", "model_id")

            new_models_df = today_df.join(yesterday_df, on="model_id", how="left_anti")

            print(f"\nFound {new_models_df.count()} new models today:")
            new_models_df.show(truncate=False)

        except AnalysisException as e:
            print(f"\nCould not run comparison (this is expected on the first day). Error: {e}")
            print("\nAssuming all models from today are new:")
            today_df.show(truncate=False)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        # CORRECTED ERROR HANDLING: Exit with a non-zero code to fail the Airflow task
        sys.exit(1)

    finally:
        print("\nStopping Spark session.")
        spark.stop()

if __name__ == "__main__":
    compare_daily_model_snapshots()