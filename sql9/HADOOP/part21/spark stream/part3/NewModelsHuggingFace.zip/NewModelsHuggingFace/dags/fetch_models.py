import csv
import datetime
import os
import sys
from huggingface_hub import HfApi

def fetch_multilingual_asr_models():
    """
    Fetches all models from the Hugging Face Hub that are tagged for
    'automatic-speech-recognition' and 'multilingual', then saves them to a CSV file.
    """
    # CORRECTED PATH: This path corresponds to the mounted volume in docker-compose.yaml
    OUTPUT_DIR = "/opt/airflow/output"
    
    try:
        print("Connecting to Hugging Face Hub API...")
        api = HfApi()
        
        models_generator = api.list_models(
            task="automatic-speech-recognition",
            tags=["multilingual"],
            sort="likes",
            direction=-1
        )

        models_list = list(models_generator)
        print(f"Found {len(models_list)} multilingual Speech-to-Text models.")

        if not models_list:
            print("No models found matching the criteria. Exiting.")
            return

        os.makedirs(OUTPUT_DIR, exist_ok=True)

        today_str = datetime.date.today().strftime('%Y%m%d')
        filename = f"{today_str}.csv"
        filepath = os.path.join(OUTPUT_DIR, filename)

        print(f"Writing data to {filepath}...")

        with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["Model ID", "Likes", "Downloads"])
            for model in models_list:
                writer.writerow([model.modelId, model.likes, model.downloads])
        
        print(f"Successfully wrote {len(models_list)} models to {filepath}")

    except Exception as e:
        print(f"An error occurred: {e}")
        # CORRECTED ERROR HANDLING: Exit with a non-zero code to fail the Airflow task
        sys.exit(1)

if __name__ == "__main__":
    fetch_multilingual_asr_models()
