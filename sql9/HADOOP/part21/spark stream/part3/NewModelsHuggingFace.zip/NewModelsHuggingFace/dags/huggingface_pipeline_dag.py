from __future__ import annotations

import pendulum

from airflow.models.dag import DAG
from airflow.operators.bash import BashOperator

with DAG(
    dag_id="huggingface_model_pipeline",
    start_date=pendulum.datetime(2025, 1, 1, tz="UTC"),
    schedule="@daily",  # This runs the DAG once a day at midnight UTC
    catchup=False,
    tags=["huggingface", "models"],
) as dag:
    # Define the base paths used by the scripts
    # AIRFLOW_HOME is /opt/airflow by default in the official images
    base_path = "$AIRFLOW_HOME/dags"

    # Task 1: Fetch the models and save them to a CSV file
    # The output will be in the mounted /opt/airflow/output directory
    fetch_task = BashOperator(
        task_id="fetch_daily_models",
        bash_command=f"python {base_path}/fetch_models.py",
    )

    # Task 2: Run the Spark job to compare today's file with yesterday's
    # The spark-submit command is available in the Airflow environment
    compare_task = BashOperator(
        task_id="compare_with_previous_day",
        bash_command=f"spark-submit {base_path}/compare_models.py",
    )

    # Set the task dependency: fetch_task must complete successfully before compare_task runs
    fetch_task >> compare_task
